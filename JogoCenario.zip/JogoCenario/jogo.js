class JogoCenario extends JS_CG_2D_API {
	acaoAoIniciar() {

        // imagens
		this.sol = new Image();
		this.sol.src = "img/sol.png";

		this.casa = new Image();
		this.casa.src = "img/casa.png";

		this.arvore = new Image();
		this.arvore.src = "img/arvore.png";
	}

	atualizar() {
	}

	desenhar() {

        //ceu
		this.limparTela("#75c9f5");

        //grama
		this.preenchimento("#55a957");
		this.retangulo(0, 450, 800, 150, Estilo.PREENCHIDO);

        //texto
		this.preenchimento("white");
		this.texto("MEU CENARIO", 280, 60, 32, "bold");

        //posicionamento das imagens
		if (this.sol.complete) {
			this.imagem(this.sol, 640, 40, 110, 110);
		}
		if (this.casa.complete) {
			this.imagem(this.casa, 300, 220, 420, 300);
		}
		if (this.arvore.complete) {
			this.imagem(this.arvore, 90, 310, 180, 150);
		}

		this.preenchimento("#25435a");
		this.texto("QUE BARBADA!", 320, 540, 24);
	}
}
//canvas
window.addEventListener("load", () => {
	new JogoCenario("Meu Cenario", "gameCanvas", 800, 600);
});
